export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { type, data } = req.body;
  const token = process.env.NOTION_TOKEN;

  if (!token) return res.status(500).json({ error: 'Notion token not configured' });

  try {
    let dbId, properties;

    if (type === 'customer') {
      dbId = 'd65bd4806feb427dac3da44f096a666a';
      properties = {
        'Customer Name': { title: [{ text: { content: data.name || '' } }] },
        'Phone': { phone_number: data.phone || null },
        'Email': { email: data.email || null },
        'Address': { rich_text: [{ text: { content: data.address || '' } }] },
        'Postcode': { rich_text: [{ text: { content: data.postcode || '' } }] },
        'Lead Source': { select: data.leadSource ? { name: data.leadSource } : null },
        'Property Type': { select: data.propertyType ? { name: data.propertyType } : null },
        'Roof Type': { select: data.roofType ? { name: data.roofType } : null },
        'Notes': { rich_text: [{ text: { content: data.notes || '' } }] },
      };
    } else {
      dbId = 'aa3a8478a70a40d78c7622f976e0df3a';
      properties = {
        'Job Title': { title: [{ text: { content: data.jobTitle || `Survey - ${data.propertyAddress || ''}` } }] },
        'Property Address': { rich_text: [{ text: { content: data.propertyAddress || '' } }] },
        'Survey Type': { select: data.surveyType ? { name: data.surveyType } : null },
        'Job Stage': { select: { name: 'Survey Booked' } },
        'Roof Condition': { select: data.roofCondition ? { name: data.roofCondition } : null },
        'Roof Age (Approx)': { select: data.roofAge ? { name: data.roofAge } : null },
        'Approx Roof Area (m²)': { number: data.roofArea ? parseFloat(data.roofArea) : null },
        'Issues Found': { rich_text: [{ text: { content: data.issuesFound || '' } }] },
        'Surveyor Recommendation': { rich_text: [{ text: { content: data.recommendation || '' } }] },
        'Access Notes': { rich_text: [{ text: { content: data.accessNotes || '' } }] },
        'Previous Repairs?': { checkbox: !!data.previousRepairs },
        'Previous Repair Notes': { rich_text: [{ text: { content: data.previousRepairNotes || '' } }] },
        'Scaffold Required?': { checkbox: !!data.scaffoldRequired },
        'Asbestos Risk?': { checkbox: !!data.asbestosRisk },
        'Quote Required?': { checkbox: !!data.quoteRequired },
        // Flat roof
        'FR — Surface Type': { select: data.frSurfaceType ? { name: data.frSurfaceType } : null },
        'FR — Deck Condition': { select: data.frDeckCondition ? { name: data.frDeckCondition } : null },
        'FR — Standing Water?': { checkbox: !!data.frStandingWater },
        'FR — Blistering / Cracking / Slumping?': { checkbox: !!data.frBlistering },
        'FR — Upstands Condition': { select: data.frUpstands ? { name: data.frUpstands } : null },
        'FR — Flashings Condition': { select: data.frFlashings ? { name: data.frFlashings } : null },
        'FR — Outlets / Drainage': { select: data.frDrainage ? { name: data.frDrainage } : null },
        'FR — Parapet Walls Condition': { select: data.frParapet ? { name: data.frParapet } : null },
        'FR — Rooflight / Hatch Present?': { checkbox: !!data.frRooflight },
        'FR — Previous Overlay?': { checkbox: !!data.frPreviousOverlay },
        'FR — Recommended System': { select: data.frRecommendedSystem ? { name: data.frRecommendedSystem } : null },
        // Pitched
        'PT — Tile Type': { select: data.ptTileType ? { name: data.ptTileType } : null },
        'PT — Ridge Type': { select: data.ptRidgeType ? { name: data.ptRidgeType } : null },
        'PT — Ridge & Hip Condition': { select: data.ptRidgeCondition ? { name: data.ptRidgeCondition } : null },
        'PT — Valley Type': { select: data.ptValleyType ? { name: data.ptValleyType } : null },
        'PT — Valleys Condition': { select: data.ptValleysCondition ? { name: data.ptValleysCondition } : null },
        'PT — No. Missing / Broken Tiles': { number: data.ptMissingTiles ? parseInt(data.ptMissingTiles) : null },
        'PT — Felt Visible from Loft?': { checkbox: !!data.ptFeltVisible },
        'PT — Felt Condition': { select: data.ptFeltCondition ? { name: data.ptFeltCondition } : null },
        'PT — Moss / Algae Growth?': { checkbox: !!data.ptMoss },
        'PT — Solar Panels Present?': { checkbox: !!data.ptSolar },
        'PT — Chimney Present?': { checkbox: !!data.ptChimney },
        // Fascias
        'FS — Current Material': { select: data.fsMaterial ? { name: data.fsMaterial } : null },
        'FS — Fascia Condition': { select: data.fsFasciaCondition ? { name: data.fsFasciaCondition } : null },
        'FS — Soffit Condition': { select: data.fsSoffitCondition ? { name: data.fsSoffitCondition } : null },
        'FS — Guttering Type': { select: data.fsGutterType ? { name: data.fsGutterType } : null },
        'FS — Guttering Condition': { select: data.fsGutterCondition ? { name: data.fsGutterCondition } : null },
        'FS — Downpipes Condition': { select: data.fsDownpipes ? { name: data.fsDownpipes } : null },
        'FS — Full Replacement or Repair?': { select: data.fsReplacement ? { name: data.fsReplacement } : null },
        'FS — Colour Preference': { rich_text: [{ text: { content: data.fsColour || '' } }] },
        'FS — Soffit Vents Present?': { checkbox: !!data.fsSoffitVents },
        'FS — Asbestos Risk (Pre-2000)?': { checkbox: !!data.fsAsbestos },
        // Chimney
        'CH — Chimney Condition': { select: data.chChimneyCondition ? { name: data.chChimneyCondition } : null },
        'CH — Lead Flashings Condition': { select: data.chLeadFlashings ? { name: data.chLeadFlashings } : null },
        'CH — Flaunching Condition': { select: data.chFlaunching ? { name: data.chFlaunching } : null },
        'CH — Pot / Terminal Condition': { select: data.chPot ? { name: data.chPot } : null },
        'CH — Gas Flue Present?': { checkbox: !!data.chGasFlue },
        'CH — Parapet / Coping Stones?': { checkbox: !!data.chParapet },
        'CH — Render / Pointing Required?': { checkbox: !!data.chRender },
      };
      // Clean nulls
      Object.keys(properties).forEach(k => {
        const v = properties[k];
        if (v.select && v.select === null) delete properties[k];
        if (v.number === null) delete properties[k];
        if (v.rich_text && v.rich_text[0].text.content === '') delete properties[k];
      });
    }

    const response = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28',
      },
      body: JSON.stringify({ parent: { database_id: dbId }, properties }),
    });

    const result = await response.json();
    if (!response.ok) return res.status(400).json({ error: result.message || 'Notion error', details: result });
    res.status(200).json({ success: true, id: result.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
